<?php 

class Equipements extends Controller {

    public function index (){
        $this->loadModel ("Equipement");
        echo "bienvenue a l'acceuil ";
    }

}