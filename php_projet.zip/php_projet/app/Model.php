<?php 
abstract class Model {
    //informations de base de donnees
    private $host = "localhost";
    private $db_name="computer_equip";
    private $username = "root";
    private $password="";

    //propriete contenant la connexion 

    protected $_connexion;

    //propriete contenant les informations de requete

    public $table;
    public $id;

    public function getConnection(){
        $this->_connexion = null;
        try{
            $this->_connexion = new PDO("mysql:host=".$this->host.";dbname=".$this->db_name,$this->username,$this->password);
            $this->_connexion->exec("set names utf8");
        }catch (PDOException $exception){
            echo"error: ".$exception->getMessage();

        }

    }

    

}