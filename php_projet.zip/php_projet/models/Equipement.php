<?php 
class Equipement extends Model {

    public function __construct()

    {
        $this->table ="compu_equipement";
        $this->getConnection();
        
    }

}